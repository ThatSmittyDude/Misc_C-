#include <iostream>

int input_1 = 16384;
int input_2 = 3;
int count1 = 0;
int count2 = 0;
int count3 = 0;
int count4 = 0;
int count5 = 0;
float count01 = 0;
float count02 = 0;
float float_sum = 0;
int count10 = 0;
int count20 = 0;
int count30 = 0;
int count40 = 0;
int count50 = 0;
int count100 = 0;
int count200 = 0;
int count300 = 0;
int count400 = 0;
int count500 = 0;
int count1000 = 0;
int count2000 = 0;
int count3000 = 0;
int count4000 = 0;
int count5000 = 0;
int a = 0;
int b = 0;
int carry = 0;
int counts_sum = 0;

#include <iostream>

/*
================
INTEGER DIVISION
================
*/

void integer_division(){

//Division_5000
        while(input_1 > 15000){
        //std::cout << "                division_5000()\n";
                a = count5000;
                b = 5000;
                input_2 = 15000;
                count5000 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_4000
        while(input_1 > 12000){
        //std::cout << "                division_4000()\n";
                a = count4000;
                b = 4000;
                input_2 = 12000;
                count4000 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_3000
        while(input_1 > 9000){
        //std::cout << "                division_3000\n";
                a = count3000;
                b = 3000;
                input_2 = 9000;
                count3000 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_2000
        while(input_1 > 6000){
        //std::cout << "                division_2000\n";
                a = count2000;
                b = 2000;
                input_2 = 6000;
                count2000 = a + b;
                input_1 = input_1 - input_2;
        }

//Divsion_1000
        while(input_1 > 3000){
        //std::cout << "                division_1000\n";
                a = count1000;
                b = 1000;
                input_2 = 3000;
                count1000 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_500
        while(input_1 > 1500){
        //std::cout << "                division_500\n";
                a = count500;
                b = 500;
                input_2 = 1500;
                count500 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_400
        while(input_1 > 1200){
        //std::cout << "                division_400\n";
                a = count400;
                b = 400;
                input_2 = 1200;
                count400 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_300
        while(input_1 > 900){
        //std::cout << "                division_300\n";
                a = count300;
                b = 300;
                input_2 = 900;
                count300 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_200
        while(input_1 > 600){
        //std::cout << "                division_200\n";
                a = count200;
                b = 200;
                input_2 = 600;
                count200 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_100
	while(input_1 > 300){
	//std::cout << "		division_100\n";
		a = count100;
		b = 100;
		input_2 = 300;
		count100 = a + b;
		input_1 = input_1 - input_2;
	}

//Division_50
        while(input_1 > 150){
        //std::cout << "                division_50\n";
                a = count50;
                b = 50;
                input_2 = 150;
                count50 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_40
        while(input_1 > 120){
        //std::cout << "                division_40\n";
                a = count40;
                b = 40;
                input_2 = 120;
                count40 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_30
        while(input_1 > 90){
        //std::cout << "                division_30\n";
                a = count30;
                b = 30;
                input_2 = 90;
                count30 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_20
        while(input_1 > 60){
        //std::cout << "                division_20\n";
                a = count20;
                b = 20;
                input_2 = 60;
                count20 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_10
        while(input_1 > 30){
        //std::cout << "                divsion_10\n";
                a = count10;
                b = 10;
                input_2 = 30;
                count10 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_5
        while(input_1 > 15){
        //std::cout << "                division_5\n";
        	a = count5;
        	b = 5;
        	input_2 = 15;
        	count5 = a + b;
        	input_1 = input_1 - input_2;
        }

//Division_4
        while(input_1 > 12){
        //std::cout << "                division4\n";
                a = count4;
                b = 4;
                input_2 = 12;
                count4 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_3
        while(input_1 > 9){
        //std::cout << "                division_3\n";
                a = count3;
                b = 3;
                input_2 = 9;
                count3 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_2
        while(input_1 > 6){
        //std::cout << "                division_2\n";
                a = count2;
                b = 2;
                input_2 = 6;
                count2 = a + b;
                input_1 = input_1 - input_2;
        }

//Division_1
        while(input_1 > 3){
        //std::cout << "                division_1\n";
                a = count1;
                b = 1;
                input_2 = 3;
                count1 = a + b;
                input_1 = input_1 - input_2;
        }

//Add_counts
        //std::cout << "                add_counts()\n";
        counts_sum = count5000 + count4000 + count3000 + count2000 + count1000 + count500 + count400 + count300 + count200 + count100 + count50 + count40 + count30 + count20 + count10 + count5 + count4 + count3 + count2 + count1;


/*
=======================
FLOATING POINT DIVISION
=======================
*/

//Division_02
        while(input_1 > 0.6){
        //std::cout << "                division_02()\n";
                count02 = count02 + 0.2;			//float
                input_1 = input_1 - 0.6;
	}

//Division_01
        while(input_1 > 0.3){
        //std::cout << "                division_01()\n";
                count01 = count01 + 0.1;
                input_1 = input_1 - 0.3;			//float
	}

//Add_floats
        //std::cout << "                add_counts()\n";
        float_sum = count01 + count02;				//float

//convert_to_float
        //std::cout << "                convert_to_float()\n";
        counts_sum = static_cast<float>(counts_sum);		//float


//convert_input_to_float
        //std::cout << "                convert_input_to_float()\n";
        input_1 = static_cast<float>(input_1);		//float


/*
======
RESULT
======
*/

float result = float_sum + counts_sum;		//float
//int result = counts_sum;
std::cout << result << "\n";


//convert_to_int
        //std::cout << "                convert_to_int()\n";
        int count1 = static_cast<int>(count1);		//float
        int count2 = static_cast<int>(count2);
        int count3 = static_cast<int>(count3);
        int count4 = static_cast<int>(count4);
        int count5 = static_cast<int>(count5);
        int count10 = static_cast<int>(count10);
        int count20 = static_cast<int>(count20);
        int count30 = static_cast<int>(count30);
        int count40 = static_cast<int>(count40);
        int count50 = static_cast<int>(count50);
        int count100 = static_cast<int>(count100);
        int count200 = static_cast<int>(count200);
        int count300 = static_cast<int>(count300);
        int count400 = static_cast<int>(count400);
        int count500 = static_cast<int>(count500);
        int count1000 = static_cast<int>(count1000);
        int count2000 = static_cast<int>(count2000);
        int count3000 = static_cast<int>(count3000);
        int count4000 = static_cast<int>(count4000);
        int count5000 = static_cast<int>(count5000);
        int counts_sum = static_cast<int>(counts_sum);
	int float_sum = static_cast<int>(float_sum);


//convert_input_to_int
        //std::cout << "                convert_input_to_int()\n";
        int input_1 = static_cast<int>(input_1);		//float

/*
=====
RESET
=====
*/
	//std::cout << "		reset()\n";
	input_1 = 16384;
	input_2 = 3;
	count1 = count1 ^ count1;
	count2 = count2 ^ count2;
	count3 = count3 ^ count3;
	count4 = count4 ^ count4;
	count5 = count5 ^ count5;

	count01 = count01 - count01;
	count02 = count02 - count02;

	count10 = count10 ^ count10;
	count20 = count20 ^ count20;
	count30 = count30 ^ count30;
	count40 = count40 ^ count40;
	count50 = count50 ^ count50;

	count100 = count100 ^ count100;
	count200 = count200 ^ count200;
	count300 = count300 ^ count300;
	count400 = count400 ^ count400;
	count500 = count500 ^ count500;

	count1000 = count1000 ^ count1000;
	count2000 = count2000 ^ count2000;
	count3000 = count3000 ^ count3000;
	count4000 = count4000 ^ count4000;
	count5000 = count5000 ^ count5000;

	counts_sum = counts_sum ^ counts_sum;
	float_sum = float_sum ^ float_sum; 	//float
}

void cycle_1(){
	//std::cout << "		cycle_1()\n";
	integer_division();
}

/*
void ten_cycles(){
	//std::cout << "		ten_cycles()\n";
	cycle_1();
	cycle_1();
	cycle_1();
	cycle_1();
	cycle_1();

	cycle_1();
	cycle_1();
	cycle_1();
	cycle_1();
	cycle_1();
}

void one_hundred(){
	//std::cout << "		one_hundred()\n";
	ten_cycles();
	ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
        ten_cycles();
}

void one_thousand(){
	//std::cout << "		one_thousand()\n";
	one_hundred();
	one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
        one_hundred();
}

void ten_thousand(){
	//std::cout << "		ten_thousand()\n";
	one_thousand();
	one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
        one_thousand();
}

void one_hundred_thousand(){
	//std::cout << "		one_hundred_thousand()\n";
	ten_thousand();
	ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
        ten_thousand();
}

void one_million(){
	//std::cout << "		one_million()\n";
	one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
        one_hundred_thousand();
}
*/

int main(){
	//std::cout << "		main()\n";
	cycle_1();
}
